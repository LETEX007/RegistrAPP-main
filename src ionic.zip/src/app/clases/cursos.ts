
export class Cursos {
    id:number;
    nombre:string;
    seccion:string;
}
