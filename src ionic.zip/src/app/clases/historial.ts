

export class Historial {
    id:number;
    // alumno:string;
    curso:string;
    fecha:string;
    presente:boolean;
}
