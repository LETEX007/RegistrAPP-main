import { Historial } from './historial';

describe('Historial', () => {
  it('should create an instance', () => {
    expect(new Historial()).toBeTruthy();
  });
});
