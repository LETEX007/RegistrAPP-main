import { Component, OnInit } from '@angular/core';
import { Router, NavigationExtras } from '@angular/router';
import { BarcodeScanner } from '@capacitor-community/barcode-scanner';
import { ToastController } from '@ionic/angular';


@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  dato:any;
  user = {
    usuario: "",
    clave: ""
  }
  field: string = "";
  constructor(private router: Router, public toastController: ToastController) { } 
  
  ngOnInit() {
  }

  ingresar() {
    if (this.validateModel(this.user)) {
      this.presentToast("Bienvenido "+this.user.usuario, 3000)
    
      let navigationExtras: NavigationExtras = {
        state: {
          user: this.user 
        }
      };
      localStorage.setItem('rango',this.user.usuario) 
      this.router.navigate(['/home'], navigationExtras); 
    }else{
      this.presentToast("Porfavor ingrese "+this.field);
    }

  }

  registrar(){
    let navigationExtras: NavigationExtras={
      state:{dato:this.dato}
    };
    this.router.navigate(['/home'],navigationExtras)
  }

  validateModel(model: any) {
    for (var [key, value] of Object.entries(model)) {

      if (value == "") {
        this.field = key;
        return false;
      }
    }
    return true;
  }
  async presentToast(msg: string, duration?: number) {
    const toast = await this.toastController.create({
      message: msg,
      duration: duration ? duration : 2000 
    });
    toast.present();
  }
  recupera(){
    let navigationExtras: NavigationExtras={
      state:{dato:this.dato}
    };
    this.router.navigate(['/recupera'],navigationExtras)
  }

}
