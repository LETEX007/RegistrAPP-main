import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { AlertController } from '@ionic/angular';

@Component({
  selector: 'app-asistencia',
  templateUrl: './asistencia.page.html',
  styleUrls: ['./asistencia.page.scss'],
})
export class AsistenciaPage implements OnInit {
  id:any;
  rango:any;
  cursos = [
    {
      "id":"01-09-2022",
      "fecha":"01-09-2022",
      "estado":"Presente",
      "estadoNF":"Ausente"
    },
    {
      "id":"01-09-2022",
      "fecha":"02-09-2022",
      "estado":"Presente",
      "estadoNF":"Ausente"
    }
  ]
  handlerMessage = '';
  constructor(private activatedRoute: ActivatedRoute,private alertController: AlertController) { }
  button(e)
  {
  e.attr("color","light");
  e.attr("color","danger");
  }
  async presentAlert() {
    const alert = await this.alertController.create({
      header: 'Alerta',
      subHeader: 'Cargando codigo QR',
      message: 'Se proyectara en unos segundos!',
      buttons: ['OK'],
    });

    await alert.present();
  }
  async presentAlertAlumno() {
    const alert = await this.alertController.create({
      header: 'Alerta',
      subHeader: 'Cargando codigo QR',
      message: 'Estas presente!',
      buttons: ['OK'],
    });

    await alert.present();
  }

  ngOnInit() {
    this.id = this.activatedRoute.snapshot.params['id'];
    console.log(this.id,"ID")
    this.rango = localStorage.getItem('rango')
    
  }

}
