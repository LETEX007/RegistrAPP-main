import { Component, OnInit } from '@angular/core';
import { AlertController } from '@ionic/angular';
import { Router,NavigationExtras } from '@angular/router';

@Component({
  selector: 'app-cursos',
  templateUrl: './cursos.page.html',
  styleUrls: ['./cursos.page.scss'],
})
export class CursosPage implements OnInit {
  buscador:string;
  dato:any;
  handlerMessage = '';
  alumnos = [
    {
      "nombre":"Gerard",
      "asignatura":"Python"
    },
    {
      "nombre":"Marco",
      "asignatura":"Javascript"
    },
    {
      "nombre":"Pedro",
      "asignatura":"C++"
    },
    {
      "nombre":"Marcel",
      "asignatura":"Python"
    },
    {
      "nombre":"Florencia",
      "asignatura":"C++"
    },
    {
      "nombre":"Joaquin",
      "asignatura":"C++"
    },
    {
      "nombre":"Marcela",
      "asignatura":"C++"
    },
    
    

  ]
  cursos = [
    {
      "id":"1",
      "nombre":"Javascript",
      "seccion":"003D"
    },
    {
      "id":"2",
      "nombre":"Python",
      "seccion":"008D"
    },
    {
      "id":"3",
      "nombre":"C++",
      "seccion":"002D"
    },
    {
      "id":"4",
      "nombre":"Javascript",
      "seccion":"001D"
    },
    {
      "id":"5",
      "nombre":"Python",
      "seccion":"011D"
    },
    {
      "id":"6",
      "nombre":"C++",
      "seccion":"007D"
    },
  ]
  async presentAlertForgot() {
    const alert = await this.alertController.create({
      header: 'Alerta',
      subHeader: 'Soporte',
      message: '¿Estas seguro de continuar?',
      buttons: [
        {
          text: 'OK',
          role: 'confirm',
          handler: () => {
            this.handlerMessage = 'Alert confirmed';
            let navigationExtras: NavigationExtras={
              state:{alumnos:this.alumnos,cursos:this.cursos}
            };
            this.router.navigate(['/home/asistencia'],navigationExtras)
          },
        },
      ],
    });

    await alert.present();
  }
  constructor(private router: Router,private alertController: AlertController) { }

  ngOnInit() {
  }
  
  asistencia(){
    let navigationExtras: NavigationExtras={
      state:{dato:this.dato}
    };
    this.router.navigate(['/asistencia'],navigationExtras)
  }

}
