import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { GoogleMap, Marker } from '@capacitor/google-maps';
import { ModalComponent } from 'src/app/components/modal/modal.component';
import { environment } from 'src/environments/environment';
import { ModalController, Platform } from '@ionic/angular';
import { Geolocation } from '@capacitor/geolocation';

@Component({
  selector: 'app-map',
  templateUrl: './map.page.html',
  styleUrls: ['./map.page.scss'],
})
export class MapPage implements OnInit {
  @ViewChild('map')
  mapRef: ElementRef<HTMLElement>;
  newMap: GoogleMap;
  
  constructor(private modalCtrl: ModalController,public plt: Platform) { }

  ngOnInit() {
   
  }
  ionViewDidEnter(){
    this.createMap();
  }
  ionViewDidLeave(){
    this.newMap.destroy();
  }

  async createMap() {
    document.querySelector('capacitor-google-maps').classList.add('activate');
    this.newMap = await GoogleMap.create({
      id: 'my-cool-map',
      element: this.mapRef.nativeElement,
      apiKey: environment.apiKey,
      config: {
        center: {
          lat: -33.4489,
          lng: -70.6693,
        },
        zoom: 8,
      },
    });
    await this.marcadores();
  }
  async mygeo(){
    Geolocation.getCurrentPosition().then(async (resp) => {
      await this.newMap.setCamera({
        coordinate: {
          lat: resp.coords.latitude,
          lng: resp.coords.longitude
        },
        zoom:15,
      });
      await this.newMap.addMarker({
        title:'Mi ubicación',
        coordinate: {
          lat: resp.coords.latitude,
          lng: resp.coords.longitude
        }
      });
    });
      
  }
    
  async marcadores(){
    // const ref: Marker[] = [
    //   // one point
    //   {
    //     coordinate:{
    //      lat:33.7,
    //      lng:-117.8, 
    //     },
    //     title:'guia pos',
    //     snippet:'cosas de guia',
    //   },
    //   // two point
    //   {        coordinate:{
    //     lat:33.7,
    //     lng:-117.2, 
    //    },
    //    title:'guia pos 2',
    //    snippet:'cosas de guia 2',}
    // ];
    // await this.newMap.addMarkers(ref);
    this.newMap.setOnMarkerClickListener(async (marca) => {
      const modal = await this.modalCtrl.create({
        component: ModalComponent,
        componentProps:{
          marca,
        },
        breakpoints:[0,0.3],
        initialBreakpoint:0.3,
      });
      modal.present();
    })
  }
}
